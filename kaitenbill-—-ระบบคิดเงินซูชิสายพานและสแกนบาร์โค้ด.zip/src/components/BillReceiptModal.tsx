import React, { useState } from 'react';
import { Check, Copy, Printer, Save, X } from 'lucide-react';
import {
  BillCalculation,
  PlateId,
  SUSHI_PLATES,
  formatThb,
} from '../data/plates';

interface BillReceiptModalProps {
  open: boolean;
  onClose: () => void;
  tableNumber: string;
  counts: Record<PlateId, number>;
  bill: BillCalculation;
  includeVat: boolean;
  diners: number;
  onSaveBill: () => void;
}

export const BillReceiptModal: React.FC<BillReceiptModalProps> = ({
  open,
  onClose,
  tableNumber,
  counts,
  bill,
  includeVat,
  diners,
  onSaveBill,
}) => {
  const [copied, setCopied] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  if (!open) return null;

  const activePlates = SUSHI_PLATES.filter((p) => (counts[p.id] || 0) > 0);
  const perPersonAfterService = diners > 1 ? bill.totalAfterService / diners : bill.totalAfterService;
  const perPersonGrand = diners > 1 ? bill.grandTotal / diners : bill.grandTotal;
  const nowStr = new Date().toLocaleString('th-TH', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  const buildReceiptText = () => {
    const lines = [
      `ใบสรุปยอดอาหารซูชิ — KaitenBill`,
      `โต๊ะ: ${tableNumber || '-'} | ${nowStr}`,
      `--------------------------------`,
      ...activePlates.map(
        (p) =>
          `${p.nameTh} (฿${p.price}) x ${counts[p.id]} = ฿${formatThb(
            p.price * counts[p.id],
            false
          )}`
      ),
      `--------------------------------`,
      `จำนวนจานทั้งหมด: ${bill.totalPlates} จาน`,
      `ราคาก่อนคิดค่าบริการ: ฿${formatThb(bill.subtotal)}`,
      `ค่าบริการ 10%: +฿${formatThb(bill.serviceCharge)}`,
      `ราคาหลังคิดค่าบริการ 10%: ฿${formatThb(bill.totalAfterService)}`,
    ];
    if (includeVat) {
      lines.push(`VAT 7%: +฿${formatThb(bill.vatAmount)}`);
      lines.push(`ยอดสุทธิรวม VAT: ฿${formatThb(bill.grandTotal)}`);
    }
    if (diners > 1) {
      lines.push(`หาร ${diners} คน: คนละ ฿${formatThb(includeVat ? perPersonGrand : perPersonAfterService)}`);
    }
    return lines.join('\n');
  };

  const handleCopyText = async () => {
    const text = buildReceiptText();
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    onSaveBill();
    setSavedNotice(true);
    window.setTimeout(() => setSavedNotice(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label="ใบสรุปยอดอาหารซูชิ"
    >
      <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-2xl border border-[#E6E3DC] shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Mobile grab handle */}
        <div className="sm:hidden pt-3 pb-1 flex justify-center">
          <div className="w-10 h-1.5 rounded-full bg-[#D7D3CA]" />
        </div>

        <div className="px-6 py-4 border-b border-[#ECE9E2] flex items-center justify-between gap-3 no-print">
          <div>
            <h3 className="text-base font-bold text-[#1A1918]">ใบสรุปยอดอาหารซูชิ</h3>
            <p className="text-xs text-[#6B6761]">
              โต๊ะ {tableNumber || 'ทั่วไป'} · {nowStr}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] rounded-xl hover:bg-[#F7F6F2] flex items-center justify-center text-[#6B6761]"
            aria-label="ปิดหน้าต่าง"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4">
          <div className="text-center pb-3 border-b border-[#ECE9E2]">
            <p className="text-lg font-bold tracking-tight text-[#1A1918]">KaitenBill Sushi</p>
            <p className="text-xs text-[#6B6761] mt-0.5">
              โต๊ะ {tableNumber || 'ทั่วไป'} · จำนวนรวม {bill.totalPlates} จาน
            </p>
          </div>

          <div className="space-y-2.5 text-sm">
            {activePlates.map((plate) => {
              const qty = counts[plate.id];
              return (
                <div key={plate.id} className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="font-medium text-[#1A1918]">{plate.nameTh}</span>
                    <span className="text-xs text-[#6B6761] ml-1.5 font-mono tabular-nums">
                      ฿{plate.price} × {qty}
                    </span>
                  </div>
                  <span className="font-mono font-semibold tabular-nums text-[#1A1918]">
                    ฿{formatThb(plate.price * qty)}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="h-px receipt-divider" />

          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-[#4D4A45]">ราคาก่อนคิดค่าบริการ</span>
              <span className="font-mono font-semibold tabular-nums text-[#1A1918]">
                ฿{formatThb(bill.subtotal)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#6B6761]">ค่าบริการ 10% (Service Charge)</span>
              <span className="font-mono tabular-nums text-[#6B6761]">
                +฿{formatThb(bill.serviceCharge)}
              </span>
            </div>
            <div className="flex items-baseline justify-between pt-2 border-t border-[#ECE9E2]">
              <span className="font-bold text-[#1A1918]">ราคาหลังคิดค่าบริการ 10%</span>
              <span className="font-mono text-xl font-bold tabular-nums text-[#C83E2B]">
                ฿{formatThb(bill.totalAfterService)}
              </span>
            </div>

            {includeVat && (
              <>
                <div className="flex items-center justify-between text-xs text-[#6B6761] pt-1">
                  <span>ภาษีมูลค่าเพิ่ม 7% (VAT)</span>
                  <span className="font-mono tabular-nums">+฿{formatThb(bill.vatAmount)}</span>
                </div>
                <div className="flex items-baseline justify-between pt-1">
                  <span className="font-bold text-[#1A1918]">ยอดสุทธิรวม VAT 7%</span>
                  <span className="font-mono text-lg font-bold tabular-nums text-[#1A1918]">
                    ฿{formatThb(bill.grandTotal)}
                  </span>
                </div>
              </>
            )}

            {diners > 1 && (
              <div className="mt-3 p-3 rounded-xl bg-[#F7F6F2] flex items-center justify-between text-xs">
                <span className="text-[#4D4A45]">หารเท่ากัน {diners} ท่าน</span>
                <span className="font-mono font-bold tabular-nums text-sm text-[#1A1918]">
                  ฿{formatThb(includeVat ? perPersonGrand : perPersonAfterService)} / ท่าน
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="p-4 border-t border-[#ECE9E2] bg-[#FAF9F6] flex flex-wrap gap-2 no-print pb-safe">
          <button
            type="button"
            onClick={handleSave}
            className="flex-1 min-h-[44px] px-3 rounded-xl bg-[#C83E2B] hover:bg-[#B23423] text-white text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap"
          >
            {savedNotice ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            <span>{savedNotice ? 'บันทึกแล้ว' : 'บันทึกประวัติ'}</span>
          </button>
          <button
            type="button"
            onClick={() => void handleCopyText()}
            className="flex-1 min-h-[44px] px-3 rounded-xl bg-white hover:bg-[#F2F0EB] border border-[#E2DFD7] text-[#1A1918] text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-700" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'คัดลอกแล้ว' : 'คัดลอกสรุป'}</span>
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="min-h-[44px] min-w-[44px] px-3 rounded-xl bg-white hover:bg-[#F2F0EB] border border-[#E2DFD7] text-[#1A1918] flex items-center justify-center"
            aria-label="พิมพ์ใบเสร็จ"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
