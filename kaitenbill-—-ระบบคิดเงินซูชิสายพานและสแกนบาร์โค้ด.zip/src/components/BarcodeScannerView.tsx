import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import {
  Camera,
  CameraOff,
  CheckCircle2,
  ImageUp,
  Keyboard,
  ScanLine,
  Volume2,
  VolumeX,
  AlertCircle,
  RotateCcw,
} from 'lucide-react';
import {
  BillCalculation,
  PlateId,
  SUSHI_PLATES,
  SushiPlateTier,
  formatThb,
  parsePlateBarcode,
} from '../data/plates';
import { PlateCeramicSwatch } from './PlateStackVisual';

interface BarcodeScannerViewProps {
  counts: Record<PlateId, number>;
  bill: BillCalculation;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onScanPlate: (plate: SushiPlateTier, source: 'camera' | 'manual-code' | 'tap' | 'image-file', rawCode: string) => void;
  onUndoLastScan: () => void;
  canUndo: boolean;
  onGoToBill: () => void;
}

const READER_ELEMENT_ID = 'kaiten-qr-reader';

export const BarcodeScannerView: React.FC<BarcodeScannerViewProps> = ({
  counts,
  bill,
  soundEnabled,
  onToggleSound,
  onScanPlate,
  onUndoLastScan,
  canUndo,
  onGoToBill,
}) => {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const lastScanRef = useRef<{ code: string; time: number }>({ code: '', time: 0 });
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [cameraActive, setCameraActive] = useState(false);
  const [cameraBusy, setCameraBusy] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manualInput, setManualInput] = useState('');
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error';
    title: string;
    detail: string;
    plate?: SushiPlateTier;
  } | null>(null);

  const handleDecodedCode = (
    rawCode: string,
    source: 'camera' | 'manual-code' | 'tap' | 'image-file'
  ) => {
    const now = Date.now();
    // Cooldown debounce for continuous live camera scanning
    if (
      source === 'camera' &&
      lastScanRef.current.code === rawCode &&
      now - lastScanRef.current.time < 1300
    ) {
      return;
    }
    lastScanRef.current = { code: rawCode, time: now };

    const matched = parsePlateBarcode(rawCode);
    if (matched) {
      onScanPlate(matched, source, rawCode);
      setFeedback({
        type: 'success',
        title: `เพิ่ม ${matched.nameTh} (+฿${matched.price})`,
        detail: `รหัส ${rawCode} · ${matched.tierLabelTh}`,
        plate: matched,
      });
    } else {
      setFeedback({
        type: 'error',
        title: 'ไม่พบรหัสจานซูชิที่รองรับ',
        detail: `อ่านได้ "${rawCode}" — รองรับรหัส SUSHI-W30, R40, S60, G80, B120 หรือบาร์โค้ด 13 หลัก`,
      });
    }
  };

  const stopCamera = async () => {
    setCameraBusy(true);
    try {
      if (scannerRef.current && scannerRef.current.isScanning) {
        await scannerRef.current.stop();
      }
      if (scannerRef.current) {
        scannerRef.current.clear();
      }
    } catch {
      // Ignore cleanup errors
    } finally {
      setCameraActive(false);
      setCameraBusy(false);
    }
  };

  const startCamera = async () => {
    setCameraError(null);
    setCameraBusy(true);
    try {
      if (!scannerRef.current) {
        scannerRef.current = new Html5Qrcode(READER_ELEMENT_ID, {
          verbose: false,
          formatsToSupport: [
            Html5QrcodeSupportedFormats.QR_CODE,
            Html5QrcodeSupportedFormats.EAN_13,
            Html5QrcodeSupportedFormats.EAN_8,
            Html5QrcodeSupportedFormats.CODE_128,
            Html5QrcodeSupportedFormats.CODE_39,
            Html5QrcodeSupportedFormats.UPC_A,
          ],
        });
      }

      if (scannerRef.current.isScanning) {
        await scannerRef.current.stop();
      }

      await scannerRef.current.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 220, height: 220 },
          aspectRatio: 1.333,
        },
        (decodedText) => {
          handleDecodedCode(decodedText, 'camera');
        },
        () => {
          // Per-frame miss is normal; stay silent
        }
      );

      setCameraActive(true);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'ไม่สามารถเปิดกล้องได้ในอุปกรณ์นี้';
      setCameraError(
        `ไม่สามารถเปิดกล้องได้ (${msg}) — คุณสามารถอัปโหลดรูปภาพบาร์โค้ด/QR พิมพ์รหัส หรือกดทดสอบสแกนจานด้านข้างได้ทันที`
      );
      setCameraActive(false);
    } finally {
      setCameraBusy(false);
    }
  };

  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        const instance = scannerRef.current;
        if (instance.isScanning) {
          void instance.stop().then(() => instance.clear()).catch(() => {});
        } else {
          try {
            instance.clear();
          } catch {
            // ignore
          }
        }
      }
    };
  }, []);

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCameraError(null);

    try {
      if (!scannerRef.current) {
        scannerRef.current = new Html5Qrcode(READER_ELEMENT_ID, { verbose: false });
      }
      if (scannerRef.current.isScanning) {
        await scannerRef.current.stop();
        setCameraActive(false);
      }
      const decodedText = await scannerRef.current.scanFile(file, false);
      handleDecodedCode(decodedText, 'image-file');
    } catch {
      setFeedback({
        type: 'error',
        title: 'ไม่พบบาร์โค้ดหรือคิวอาร์โค้ดในภาพ',
        detail: 'ลองใช้ภาพที่คมชัดขึ้น หรือดาวน์โหลด QR ของจานจากแท็บ "รหัส QR จาน" มาทดสอบ',
      });
    } finally {
      e.target.value = '';
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInput.trim()) return;
    handleDecodedCode(manualInput.trim(), 'manual-code');
    setManualInput('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
      {/* Left 7 cols: Live Camera & Manual Scanner */}
      <div className="lg:col-span-7 space-y-5">
        <div className="bg-white rounded-2xl border border-[#E6E3DC] p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div>
              <h2 className="text-lg font-bold text-[#1A1918]">
                สแกนบาร์โค้ด / คิวอาร์โค้ดอัตโนมัติ
              </h2>
              <p className="text-sm text-[#6B6761] mt-0.5">
                รองรับ QR Code, EAN-13, Code 128 และเครื่องยิงบาร์โค้ด USB
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onToggleSound}
                className="min-h-[44px] min-w-[44px] px-3 rounded-xl border border-[#E6E3DC] text-[#1A1918] hover:bg-[#F7F6F2] transition-colors flex items-center justify-center gap-1.5 text-sm font-medium whitespace-nowrap shrink-0"
                title={soundEnabled ? 'ปิดเสียงบี๊บ' : 'เปิดเสียงบี๊บ'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-[#6B6761]" />}
                <span className="hidden sm:inline">{soundEnabled ? 'เสียงเปิด' : 'เสียงปิด'}</span>
              </button>

              {canUndo && (
                <button
                  type="button"
                  onClick={onUndoLastScan}
                  className="min-h-[44px] px-3.5 rounded-xl border border-[#E6E3DC] text-[#1A1918] hover:bg-[#F7F6F2] transition-colors flex items-center gap-1.5 text-sm font-medium whitespace-nowrap shrink-0"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>ย้อนกลับ</span>
                </button>
              )}
            </div>
          </div>

          {/* Camera Viewfinder */}
          <div className="relative rounded-2xl overflow-hidden bg-[#141413] min-h-[280px] sm:min-h-[320px] flex flex-col items-center justify-center">
            <div id={READER_ELEMENT_ID} className="w-full h-full" />

            {!cameraActive && (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-[#181716]">
                <div className="w-16 h-16 rounded-2xl border border-white/15 bg-white/5 flex items-center justify-center mb-4">
                  <ScanLine className="w-8 h-8 text-[#E0604E]" />
                </div>
                <p className="text-base font-semibold text-white">
                  พร้อมเปิดกล้องสแกนจานซูชิ
                </p>
                <p className="text-xs sm:text-sm text-neutral-400 mt-1 max-w-sm">
                  เล็งกล้องไปที่บาร์โค้ดหรือคิวอาร์โค้ดใต้จาน ระบบจะบวกราคาตามสีจานและคำนวณค่าบริการ 10% ให้ทันที
                </p>
                <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                  <button
                    type="button"
                    disabled={cameraBusy}
                    onClick={() => void startCamera()}
                    className="min-h-[46px] px-5 py-2.5 rounded-xl bg-[#C83E2B] hover:bg-[#B23423] text-white text-sm font-semibold transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 disabled:opacity-60"
                  >
                    <Camera className="w-4 h-4" />
                    <span>{cameraBusy ? 'กำลังเปิดกล้อง...' : 'เปิดกล้องสแกน'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="min-h-[46px] px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-sm font-medium transition-colors flex items-center gap-2 whitespace-nowrap shrink-0"
                  >
                    <ImageUp className="w-4 h-4" />
                    <span>สแกนจากรูปภาพ</span>
                  </button>
                </div>
              </div>
            )}

            {cameraActive && (
              <>
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                  <div className="w-52 h-52 sm:w-60 sm:h-60 rounded-2xl border-2 border-[#E0604E] shadow-[0_0_0_9999px_rgba(0,0,0,0.35)]" />
                </div>
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
                  <span className="px-3 py-1.5 rounded-lg bg-black/70 text-white text-xs font-medium">
                    เล็งคิวอาร์โค้ดหรือบาร์โค้ดให้อยู่ในกรอบ
                  </span>
                  <button
                    type="button"
                    onClick={() => void stopCamera()}
                    className="min-h-[40px] px-3.5 py-2 rounded-xl bg-black/80 hover:bg-black text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <CameraOff className="w-3.5 h-3.5" />
                    <span>ปิดกล้อง</span>
                  </button>
                </div>
              </>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={(e) => void handleImageFileChange(e)}
              className="hidden"
            />
          </div>

          {cameraError && (
            <div className="mt-4 p-3.5 rounded-xl bg-[#FDF2F0] border border-[#F3C8C1] flex items-start gap-2.5 text-sm text-[#8F281A]">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <p>{cameraError}</p>
            </div>
          )}

          {/* Last Scan Feedback */}
          {feedback && (
            <div
              className={`mt-4 p-3.5 rounded-xl border flex items-center gap-3 ${
                feedback.type === 'success'
                  ? 'bg-[#F4F8F4] border-[#CFE3D0] text-[#1A4220]'
                  : 'bg-[#FDF2F0] border-[#F3C8C1] text-[#8F281A]'
              }`}
            >
              {feedback.plate ? (
                <PlateCeramicSwatch plate={feedback.plate} size={40} />
              ) : feedback.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 shrink-0" />
              )}
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold truncate">{feedback.title}</p>
                <p className="text-xs opacity-80 truncate">{feedback.detail}</p>
              </div>
            </div>
          )}

          {/* Manual Barcode / USB Scanner Input */}
          <form onSubmit={handleManualSubmit} className="mt-5 pt-5 border-t border-[#ECE9E2]">
            <label
              htmlFor="manual-barcode-input"
              className="block text-sm font-semibold text-[#1A1918] mb-2"
            >
              ยิงบาร์โค้ดด้วยเครื่องสแกน หรือพิมพ์รหัสจานด้วยตนเอง
            </label>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1">
                <Keyboard className="w-4 h-4 text-[#6B6761] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="manual-barcode-input"
                  type="text"
                  value={manualInput}
                  onChange={(e) => setManualInput(e.target.value)}
                  placeholder="เช่น SUSHI-R40, 8850100001207, gold หรือ 80"
                  className="w-full min-h-[46px] pl-10 pr-4 rounded-xl bg-[#F7F6F2] border border-[#E2DFD7] text-sm text-[#1A1918] placeholder:text-[#8E8980] focus:outline-none focus:border-[#C83E2B] focus:bg-white transition-colors font-mono"
                />
              </div>
              <button
                type="submit"
                className="min-h-[46px] px-5 rounded-xl bg-[#1A1918] hover:bg-[#312F2D] text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                เพิ่มจานจากรหัส
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Right 5 cols: Instant Scan Simulator + Running Bill */}
      <div className="lg:col-span-5 space-y-5">
        {/* Live Bill Summary Card */}
        <div className="bg-white rounded-2xl border border-[#E6E3DC] p-5">
          <div className="flex items-center justify-between gap-2 mb-3">
            <h3 className="text-base font-bold text-[#1A1918]">ยอดคำนวณอัตโนมัติปัจจุบัน</h3>
            <span className="text-xs font-mono tabular-nums text-[#6B6761]">
              {bill.totalPlates} จาน
            </span>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between text-[#4D4A45]">
              <span>ราคาก่อนคิดค่าบริการ</span>
              <span className="font-mono font-semibold tabular-nums text-[#1A1918]">
                ฿{formatThb(bill.subtotal)}
              </span>
            </div>
            <div className="flex items-center justify-between text-[#6B6761]">
              <span>ค่าบริการ 10% (Service Charge)</span>
              <span className="font-mono tabular-nums">+฿{formatThb(bill.serviceCharge)}</span>
            </div>
            <div className="h-px receipt-divider my-2" />
            <div className="flex items-baseline justify-between pt-1">
              <span className="font-semibold text-[#1A1918]">ยอดหลังคิดค่าบริการ 10%</span>
              <span className="font-mono text-2xl font-bold tabular-nums text-[#C83E2B]">
                ฿{formatThb(bill.totalAfterService)}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onGoToBill}
            className="mt-4 w-full min-h-[44px] px-4 rounded-xl bg-[#F7F6F2] hover:bg-[#ECEAE3] border border-[#E2DFD7] text-sm font-semibold text-[#1A1918] transition-colors"
          >
            ดูใบเสร็จและแยกหารบิล
          </button>
        </div>

        {/* Instant 1-Tap Plate Barcode Simulator */}
        <div className="bg-white rounded-2xl border border-[#E6E3DC] p-5">
          <h3 className="text-base font-bold text-[#1A1918]">
            ทดสอบสแกนบาร์โค้ดแต่ละสีจาน
          </h3>
          <p className="text-xs text-[#6B6761] mt-0.5 mb-4">
            แตะจานด้านล่างเพื่อจำลองการยิงบาร์โค้ดเข้าสู่บิลทันทีโดยไม่ต้องเปิดกล้อง
          </p>

          <div className="space-y-2.5">
            {SUSHI_PLATES.map((plate) => {
              const qty = counts[plate.id] || 0;
              return (
                <button
                  key={plate.id}
                  type="button"
                  onClick={() => handleDecodedCode(plate.qrCode, 'tap')}
                  className="w-full min-h-[60px] px-3.5 py-2.5 rounded-xl border border-[#E6E3DC] hover:border-[#C83E2B] hover:bg-[#FDFBF9] active:scale-[0.99] transition-all flex items-center justify-between gap-3 text-left"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <PlateCeramicSwatch plate={plate} size={40} />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#1A1918] truncate">
                        {plate.nameTh}
                      </p>
                      <p className="text-xs font-mono text-[#6B6761] truncate">
                        {plate.qrCode} · {plate.ean13}
                      </p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold font-mono tabular-nums text-[#C83E2B]">
                      +฿{plate.price}
                    </p>
                    <p className="text-xs font-mono tabular-nums text-[#6B6761]">
                      มีแล้ว {qty} จาน
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
