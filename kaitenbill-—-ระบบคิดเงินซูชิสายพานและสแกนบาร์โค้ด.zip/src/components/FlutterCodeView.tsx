import React, { useState } from 'react';
import { Check, Copy, Download, FileCode2, Terminal } from 'lucide-react';
import { FLUTTER_PROJECT_FILES, FlutterSourceFile } from '../data/flutterSource';

export const FlutterCodeView: React.FC = () => {
  const [selectedPath, setSelectedPath] = useState<string>(FLUTTER_PROJECT_FILES[1].path);
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const activeFile: FlutterSourceFile =
    FLUTTER_PROJECT_FILES.find((f) => f.path === selectedPath) ?? FLUTTER_PROJECT_FILES[0];

  const handleCopy = async (file: FlutterSourceFile) => {
    try {
      await navigator.clipboard.writeText(file.content);
      setCopiedPath(file.path);
      window.setTimeout(() => setCopiedPath(null), 2000);
    } catch {
      // Fallback copy
      const ta = document.createElement('textarea');
      ta.value = file.content;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopiedPath(file.path);
      window.setTimeout(() => setCopiedPath(null), 2000);
    }
  };

  const handleDownload = (file: FlutterSourceFile) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.label;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1A1918]">
            ซอร์สโค้ด Native Mobile App (Flutter & Dart)
          </h2>
          <p className="text-sm text-[#6B6761] mt-1">
            โครงสร้างโปรเจกต์ Flutter พร้อมใช้แพ็กเกจ mobile_scanner สแกนบาร์โค้ด/QR และคำนวณราคาก่อน-หลังค่าบริการ 10%
          </p>
        </div>
      </div>

      {/* Quick setup instructions */}
      <div className="bg-white rounded-2xl border border-[#E6E3DC] p-5 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <p className="text-xs font-semibold text-[#C83E2B] mb-1">01. สร้างโปรเจกต์และติดตั้งแพ็กเกจ</p>
          <pre className="text-xs font-mono bg-[#F7F6F2] border border-[#EAE7E0] rounded-xl p-3 text-[#1A1918] overflow-x-auto">
{`flutter create kaiten_sushi_bill
cd kaiten_sushi_bill
flutter pub get`}
          </pre>
        </div>
        <div>
          <p className="text-xs font-semibold text-[#C83E2B] mb-1">02. เพิ่มสิทธิ์กล้อง iOS (Info.plist)</p>
          <pre className="text-xs font-mono bg-[#F7F6F2] border border-[#EAE7E0] rounded-xl p-3 text-[#1A1918] overflow-x-auto">
{`<key>NSCameraUsageDescription</key>
<string>ใช้กล้องเพื่อสแกนบาร์โค้ดจานซูชิ</string>`}
          </pre>
        </div>
        <div>
          <p className="text-xs font-semibold text-[#C83E2B] mb-1">03. รันบนเครื่อง Android / iOS</p>
          <pre className="text-xs font-mono bg-[#F7F6F2] border border-[#EAE7E0] rounded-xl p-3 text-[#1A1918] overflow-x-auto">
{`# Android เพิ่มสิทธิ์ CAMERA อัตโนมัติ
flutter run --release`}
          </pre>
        </div>
      </div>

      {/* File Browser + Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        <div className="lg:col-span-4 bg-white rounded-2xl border border-[#E6E3DC] p-3 space-y-1.5">
          <div className="px-2.5 py-2 flex items-center gap-2 text-xs font-semibold text-[#6B6761]">
            <Terminal className="w-3.5 h-3.5" />
            <span>ไฟล์โปรเจกต์ Flutter (5 ไฟล์)</span>
          </div>
          {FLUTTER_PROJECT_FILES.map((file) => {
            const isSelected = file.path === activeFile.path;
            return (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedPath(file.path)}
                className={`w-full min-h-[52px] px-3 py-2.5 rounded-xl text-left transition-colors flex items-start gap-2.5 ${
                  isSelected
                    ? 'bg-[#1A1918] text-white'
                    : 'hover:bg-[#F7F6F2] text-[#1A1918]'
                }`}
              >
                <FileCode2
                  className={`w-4 h-4 shrink-0 mt-0.5 ${
                    isSelected ? 'text-[#E0604E]' : 'text-[#6B6761]'
                  }`}
                />
                <div className="min-w-0">
                  <p className="text-xs font-mono font-semibold truncate">{file.path}</p>
                  <p
                    className={`text-[11px] mt-0.5 line-clamp-2 ${
                      isSelected ? 'text-neutral-300' : 'text-[#6B6761]'
                    }`}
                  >
                    {file.summaryTh}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        <div className="lg:col-span-8 bg-[#181716] rounded-2xl border border-[#2C2A28] overflow-hidden">
          <div className="px-4 py-3 border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-sm font-mono font-semibold text-white truncate">
                {activeFile.path}
              </p>
              <p className="text-xs text-neutral-400 truncate mt-0.5">
                {activeFile.summaryTh}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => void handleCopy(activeFile)}
                className="min-h-[40px] px-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 whitespace-nowrap"
              >
                {copiedPath === activeFile.path ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>คัดลอกแล้ว</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>คัดลอกโค้ด</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => handleDownload(activeFile)}
                className="min-h-[40px] px-3.5 rounded-xl bg-[#C83E2B] hover:bg-[#B23423] text-white text-xs font-semibold transition-colors flex items-center gap-1.5 whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5" />
                <span>ดาวน์โหลด</span>
              </button>
            </div>
          </div>

          <div className="p-4 overflow-x-auto max-h-[560px] overflow-y-auto">
            <pre className="text-xs sm:text-[13px] leading-relaxed font-mono text-[#F3F1EC] whitespace-pre">
              {activeFile.content}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
