import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Download, Printer, Plus } from 'lucide-react';
import { PlateId, SUSHI_PLATES, SushiPlateTier } from '../data/plates';
import { PlateCeramicSwatch } from './PlateStackVisual';

interface QrStickersViewProps {
  onQuickAddPlate: (plate: SushiPlateTier) => void;
}

/** Deterministic crisp decorative-but-consistent EAN-13 bar pattern from digit string */
const BarcodeSvg: React.FC<{ value: string }> = ({ value }) => {
  const bars: { x: number; w: number }[] = [];
  let cursor = 6;
  // Guard start
  bars.push({ x: cursor, w: 2 });
  cursor += 4;
  bars.push({ x: cursor, w: 2 });
  cursor += 5;

  for (let i = 0; i < value.length; i++) {
    const digit = Number(value[i]) || 0;
    const w1 = (digit % 3) + 1;
    const gap1 = ((digit + 1) % 2) + 1.5;
    const w2 = ((digit + 2) % 3) + 1;
    bars.push({ x: cursor, w: w1 });
    cursor += w1 + gap1;
    bars.push({ x: cursor, w: w2 });
    cursor += w2 + 2;
  }

  // Guard end
  bars.push({ x: cursor, w: 2 });
  cursor += 4;
  bars.push({ x: cursor, w: 2 });
  cursor += 8;

  return (
    <svg
      viewBox={`0 0 ${cursor} 42`}
      className="w-full max-w-[190px] h-10 text-[#1A1918]"
      aria-label={`บาร์โค้ด ${value}`}
    >
      {bars.map((bar, idx) => (
        <rect
          key={idx}
          x={bar.x}
          y={2}
          width={bar.w}
          height={30}
          fill="currentColor"
        />
      ))}
      <text
        x={cursor / 2}
        y={40}
        textAnchor="middle"
        fontSize="8.5"
        fontFamily="JetBrains Mono, monospace"
        fill="#4D4A45"
      >
        {value}
      </text>
    </svg>
  );
};

export const QrStickersView: React.FC<QrStickersViewProps> = ({ onQuickAddPlate }) => {
  const [qrImages, setQrImages] = useState<Partial<Record<PlateId, string>>>({});

  useEffect(() => {
    let active = true;
    async function generateAll() {
      const result: Partial<Record<PlateId, string>> = {};
      for (const plate of SUSHI_PLATES) {
        try {
          const dataUrl = await QRCode.toDataURL(plate.qrCode, {
            width: 280,
            margin: 2,
            color: {
              dark: '#1A1918',
              light: '#FFFFFF',
            },
          });
          result[plate.id] = dataUrl;
        } catch {
          // ignore
        }
      }
      if (active) setQrImages(result);
    }
    void generateAll();
    return () => {
      active = false;
    };
  }, []);

  const handleDownloadQr = (plate: SushiPlateTier) => {
    const url = qrImages[plate.id];
    if (!url) return;
    const link = document.createElement('a');
    link.href = url;
    link.download = `${plate.qrCode}.png`;
    link.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 no-print">
        <div>
          <h2 className="text-xl font-bold text-[#1A1918]">
            ชุดป้าย QR Code และบาร์โค้ดประจำสีจาน
          </h2>
          <p className="text-sm text-[#6B6761] mt-1">
            สแกนป้ายเหล่านี้ด้วยแท็บ "สแกนบาร์โค้ด" หรือแอป Flutter เพื่อทดสอบระบบคิดเงินอัตโนมัติได้ทันที
          </p>
        </div>
        <button
          type="button"
          onClick={() => window.print()}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-[#1A1918] hover:bg-[#312F2D] text-white text-sm font-semibold transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
        >
          <Printer className="w-4 h-4" />
          <span>พิมพ์ชุดสติกเกอร์จาน</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {SUSHI_PLATES.map((plate) => {
          const qrSrc = qrImages[plate.id];
          return (
            <div
              key={plate.id}
              className="bg-white rounded-2xl border border-[#E6E3DC] p-5 flex flex-col justify-between gap-4 break-inside-avoid"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <PlateCeramicSwatch plate={plate} size={42} />
                  <div className="min-w-0">
                    <h3 className="text-base font-bold text-[#1A1918] truncate">
                      {plate.nameTh}
                    </h3>
                    <p className="text-xs text-[#6B6761] truncate">
                      {plate.tierLabelTh} · ฿{plate.price}
                    </p>
                  </div>
                </div>
                <span className="font-mono text-lg font-bold tabular-nums text-[#C83E2B] shrink-0">
                  ฿{plate.price}
                </span>
              </div>

              <div className="rounded-xl bg-[#F7F6F2] border border-[#EAE7E0] p-4 flex flex-col items-center justify-center gap-3">
                {qrSrc ? (
                  <img
                    src={qrSrc}
                    alt={`QR Code สำหรับ ${plate.nameTh} (${plate.qrCode})`}
                    className="w-40 h-40 rounded-lg bg-white p-1.5 border border-[#E6E3DC]"
                  />
                ) : (
                  <div className="w-40 h-40 rounded-lg bg-white border border-[#E6E3DC] flex items-center justify-center text-xs text-[#6B6761]">
                    กำลังสร้าง QR...
                  </div>
                )}

                <p className="font-mono text-sm font-bold tracking-wide text-[#1A1918]">
                  {plate.qrCode}
                </p>

                <BarcodeSvg value={plate.ean13} />
              </div>

              <p className="text-xs text-[#6B6761] leading-relaxed">
                {plate.examplesTh}
              </p>

              <div className="flex items-center gap-2 pt-2 border-t border-[#ECE9E2] no-print">
                <button
                  type="button"
                  onClick={() => handleDownloadQr(plate)}
                  className="flex-1 min-h-[42px] px-3 rounded-xl border border-[#E2DFD7] hover:bg-[#F7F6F2] text-xs font-semibold text-[#1A1918] transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>โหลด PNG</span>
                </button>
                <button
                  type="button"
                  onClick={() => onQuickAddPlate(plate)}
                  className="flex-1 min-h-[42px] px-3 rounded-xl bg-[#C83E2B] hover:bg-[#B23423] text-white text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>เพิ่มเข้าบิล</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
