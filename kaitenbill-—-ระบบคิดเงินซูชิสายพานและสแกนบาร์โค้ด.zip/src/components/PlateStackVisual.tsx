import React from 'react';
import { PlateId, SUSHI_PLATES, SushiPlateTier } from '../data/plates';

interface PlateCeramicSwatchProps {
  plate: SushiPlateTier;
  size?: number;
  showPrice?: boolean;
}

export const PlateCeramicSwatch: React.FC<PlateCeramicSwatchProps> = ({
  plate,
  size = 44,
  showPrice = true,
}) => {
  return (
    <div
      style={{ width: size, height: size }}
      className="relative shrink-0 select-none flex items-center justify-center"
      aria-hidden="true"
    >
      <svg viewBox="0 0 64 64" width={size} height={size} className="drop-shadow-xs">
        <circle
          cx="32"
          cy="32"
          r="29"
          fill={plate.plateFill}
          stroke={plate.plateRim}
          strokeWidth="3.5"
        />
        <circle
          cx="32"
          cy="32"
          r="21"
          fill="none"
          stroke={plate.plateInnerRing}
          strokeWidth="1.5"
        />
      </svg>
      {showPrice && (
        <span
          style={{ color: plate.plateTextOnSwatch }}
          className="absolute inset-0 flex items-center justify-center font-mono text-[11px] font-bold tabular-nums"
        >
          ฿{plate.price}
        </span>
      )}
    </div>
  );
};

interface PlatePhotoThumbProps {
  plate: SushiPlateTier;
  className?: string;
}

export const PlatePhotoThumb: React.FC<PlatePhotoThumbProps> = ({
  plate,
  className = 'w-16 h-16',
}) => {
  const [imgError, setImgError] = React.useState(false);

  if (imgError) {
    return (
      <div
        className={`${className} rounded-2xl bg-[#F2F0EB] border border-[#E5E2DA] flex items-center justify-center shrink-0`}
      >
        <PlateCeramicSwatch plate={plate} size={46} showPrice />
      </div>
    );
  }

  return (
    <div
      className={`${className} rounded-2xl overflow-hidden bg-[#F2F0EB] border border-[#E5E2DA] shrink-0 relative`}
    >
      <img
        src={plate.imageUrl}
        alt={`${plate.nameTh} — ${plate.examplesTh}`}
        referrerPolicy="no-referrer"
        onError={() => setImgError(true)}
        className="w-full h-full object-cover"
      />
      <span
        style={{
          backgroundColor: plate.plateFill,
          borderColor: plate.plateRim,
        }}
        className="absolute bottom-1.5 right-1.5 w-3.5 h-3.5 rounded-full border-2 shadow-xs"
        title={plate.nameTh}
      />
    </div>
  );
};

interface PlateStackVisualProps {
  counts: Record<PlateId, number>;
  totalPlates: number;
}

export const PlateStackVisual: React.FC<PlateStackVisualProps> = ({
  counts,
  totalPlates,
}) => {
  // Build flat stack list from heaviest/highest tier at bottom to lowest on top
  const orderedTiers = [...SUSHI_PLATES].reverse();
  const stack: SushiPlateTier[] = [];
  for (const tier of orderedTiers) {
    const qty = counts[tier.id] || 0;
    for (let i = 0; i < qty; i++) {
      stack.push(tier);
    }
  }

  const maxVisible = 14;
  const visibleStack = stack.slice(0, maxVisible);
  const overflowCount = Math.max(0, stack.length - maxVisible);

  if (totalPlates === 0) {
    return (
      <div className="py-5 px-4 rounded-2xl bg-[#F7F6F2] border border-[#EAE7E0] flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-[#1A1918]">ยังไม่มีจานซูชิในบิล</p>
          <p className="text-xs text-[#6B6761] mt-0.5">
            สแกนบาร์โค้ด หรือกดปุ่ม + ด้านซ้ายเพื่อเริ่มนับจาน
          </p>
        </div>
        <svg viewBox="0 0 80 34" className="w-16 h-8 shrink-0 text-[#CFCBC2]" aria-hidden="true">
          <ellipse cx="40" cy="24" rx="34" ry="7" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" />
          <ellipse cx="40" cy="15" rx="28" ry="5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" />
        </svg>
      </div>
    );
  }

  const svgHeight = Math.max(58, 30 + visibleStack.length * 8);

  return (
    <div className="py-4 px-4 rounded-2xl bg-[#F7F6F2] border border-[#EAE7E0] flex items-center justify-between gap-4">
      <div>
        <p className="text-xs text-[#6B6761]">กองจานบนโต๊ะ</p>
        <p className="text-2xl font-bold font-mono tabular-nums text-[#1A1918] mt-0.5">
          {totalPlates} <span className="text-sm font-sans font-medium text-[#6B6761]">จาน</span>
        </p>
        {overflowCount > 0 && (
          <p className="text-xs text-[#6B6761] mt-1">
            และอีก +{overflowCount} จานในบิล
          </p>
        )}
      </div>

      <svg
        viewBox={`0 0 120 ${svgHeight}`}
        style={{ height: Math.min(svgHeight, 132) }}
        className="w-28 shrink-0"
        aria-label={`ภาพจำลองกองจานซูชิจำนวน ${totalPlates} จาน`}
      >
        {/* Subtle wooden table shadow */}
        <ellipse
          cx="60"
          cy={svgHeight - 8}
          rx="46"
          ry="6"
          fill="#1A1918"
          fillOpacity="0.08"
        />
        {visibleStack.map((plate, index) => {
          const y = svgHeight - 14 - index * 7.5;
          return (
            <g key={`${plate.id}-${index}`}>
              <path
                d={`M 16 ${y} Q 60 ${y + 9} 104 ${y} L 98 ${y + 5.5} Q 60 ${y + 13} 22 ${y + 5.5} Z`}
                fill={plate.plateRim}
              />
              <ellipse
                cx="60"
                cy={y}
                rx="44"
                ry="6"
                fill={plate.plateFill}
                stroke={plate.plateRim}
                strokeWidth="1.4"
              />
              <ellipse
                cx="60"
                cy={y}
                rx="28"
                ry="3"
                fill="none"
                stroke={plate.plateInnerRing}
                strokeWidth="0.9"
              />
            </g>
          );
        })}
      </svg>
    </div>
  );
};
