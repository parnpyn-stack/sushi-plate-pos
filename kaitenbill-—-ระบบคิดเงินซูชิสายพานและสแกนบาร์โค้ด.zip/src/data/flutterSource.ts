export interface FlutterSourceFile {
  path: string;
  label: string;
  language: 'yaml' | 'dart';
  summaryTh: string;
  content: string;
}

export const FLUTTER_PROJECT_FILES: FlutterSourceFile[] = [
  {
    path: 'pubspec.yaml',
    label: 'pubspec.yaml',
    language: 'yaml',
    summaryTh: 'ตั้งค่าแพ็กเกจ mobile_scanner สำหรับสแกนบาร์โค้ด/QR และ intl สำหรับรูปแบบเงินบาท',
    content: `name: kaiten_sushi_bill
description: Native Flutter app for calculating Kaiten Sushi plate bills via barcode/QR scanning.
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.4.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  mobile_scanner: ^6.0.2
  intl: ^0.19.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^4.0.0

flutter:
  uses-material-design: true
`,
  },
  {
    path: 'lib/models/sushi_plate.dart',
    label: 'sushi_plate.dart',
    language: 'dart',
    summaryTh: 'โมเดลราคาจานซูชิ 5 สี (30/40/60/80/120 บาท) ระบบจับคู่รหัสบาร์โค้ด และคำนวณค่าบริการ 10%',
    content: `import 'package:flutter/material.dart';

enum PlateTierId { white, red, silver, gold, black }

class SushiPlateTier {
  final PlateTierId id;
  final String nameTh;
  final String examplesTh;
  final int priceThb;
  final String qrCode;
  final String ean13;
  final Color plateColor;
  final Color borderColor;
  final Color textColor;

  const SushiPlateTier({
    required this.id,
    required this.nameTh,
    required this.examplesTh,
    required this.priceThb,
    required this.qrCode,
    required this.ean13,
    required this.plateColor,
    required this.borderColor,
    required this.textColor,
  });

  static const List<SushiPlateTier> all = [
    SushiPlateTier(
      id: PlateTierId.white,
      nameTh: 'จานสีขาว',
      examplesTh: 'เมนูเริ่มต้น เช่น ยำสาหร่าย ไข่กุ้ง ซุปมิโซะ',
      priceThb: 30,
      qrCode: 'SUSHI-W30',
      ean13: '8850100000309',
      plateColor: Color(0xFFFFFFFF),
      borderColor: Color(0xFFCBD5E1),
      textColor: Color(0xFF1E293B),
    ),
    SushiPlateTier(
      id: PlateTierId.red,
      nameTh: 'จานสีแดง',
      examplesTh: 'เมนูทั่วไป เช่น แซลมอน ไข่หวาน ปูอัด',
      priceThb: 40,
      qrCode: 'SUSHI-R40',
      ean13: '8850100000408',
      plateColor: Color(0xFFC83E2B),
      borderColor: Color(0xFF992A1B),
      textColor: Color(0xFFFFFFFF),
    ),
    SushiPlateTier(
      id: PlateTierId.silver,
      nameTh: 'จานสีเงิน',
      examplesTh: 'เมนูพิเศษ เช่น มากุโระ หมึกโฮตารุ แซลมอนเบิร์น',
      priceThb: 60,
      qrCode: 'SUSHI-S60',
      ean13: '8850100000606',
      plateColor: Color(0xFFB6BDC6),
      borderColor: Color(0xFF6B7280),
      textColor: Color(0xFF111827),
    ),
    SushiPlateTier(
      id: PlateTierId.gold,
      nameTh: 'จานสีทอง/สีเหลือง',
      examplesTh: 'เมนูพรีเมียมหรือปรุงพิเศษ เช่น ปลาไหลอุนางิ เอ็นกาวะ',
      priceThb: 80,
      qrCode: 'SUSHI-G80',
      ean13: '8850100000804',
      plateColor: Color(0xFFD4A742),
      borderColor: Color(0xFF9C751D),
      textColor: Color(0xFF1F1A0F),
    ),
    SushiPlateTier(
      id: PlateTierId.black,
      nameTh: 'จานสีดำ',
      examplesTh: 'เมนูพรีเมียมสูงสุด เช่น โฮตาเตะ เนื้อวากิว A5',
      priceThb: 120,
      qrCode: 'SUSHI-B120',
      ean13: '8850100001207',
      plateColor: Color(0xFF1D1D1F),
      borderColor: Color(0xFF09090B),
      textColor: Color(0xFFFFFFFF),
    ),
  ];

  static SushiPlateTier? matchBarcode(String rawValue) {
    final code = rawValue.trim().toUpperCase();
    for (final tier in all) {
      if (code == tier.qrCode ||
          code == tier.ean13 ||
          code.contains(tier.qrCode) ||
          code.contains(tier.id.name.toUpperCase()) ||
          code == tier.priceThb.toString()) {
        return tier;
      }
    }
    return null;
  }
}

class SushiBillSummary {
  final Map<PlateTierId, int> counts;
  final double serviceChargeRate;

  const SushiBillSummary({
    required this.counts,
    this.serviceChargeRate = 0.10,
  });

  int get totalPlates => counts.values.fold(0, (a, b) => a + b);

  /// ราคาก่อนคิดค่าบริการ 10%
  double get subtotal {
    double sum = 0;
    for (final tier in SushiPlateTier.all) {
      sum += (counts[tier.id] ?? 0) * tier.priceThb;
    }
    return sum;
  }

  /// ค่าบริการ 10%
  double get serviceCharge => subtotal * serviceChargeRate;

  /// ราคาสุทธิหลังคิดค่าบริการ 10%
  double get grandTotal => subtotal + serviceCharge;
}
`,
  },
  {
    path: 'lib/main.dart',
    label: 'main.dart',
    language: 'dart',
    summaryTh: 'Entry point ของแอป Flutter พร้อม Material 3 Theme โทนร้านซูชิญี่ปุ่น',
    content: `import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const KaitenBillApp());
}

class KaitenBillApp extends StatelessWidget {
  const KaitenBillApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KaitenBill Sushi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFC83E2B),
          surface: const Color(0xFFF7F6F2),
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F6F2),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFFFFFF),
          foregroundColor: Color(0xFF1A1918),
          elevation: 0,
          scrolledUnderElevation: 1,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
`,
  },
  {
    path: 'lib/screens/home_screen.dart',
    label: 'home_screen.dart',
    language: 'dart',
    summaryTh: 'หน้าหลักนับจำนวนจานแต่ละสี แสดงยอดก่อนและหลังคิดค่าบริการ 10% พร้อมปุ่มเปิดกล้องสแกน',
    content: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/sushi_plate.dart';
import 'scanner_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Map<PlateTierId, int> _counts = {
    for (final tier in SushiPlateTier.all) tier.id: 0,
  };

  final NumberFormat _thbFormat = NumberFormat('#,##0.00', 'th_TH');

  void _increment(PlateTierId id) {
    HapticFeedback.lightImpact();
    setState(() {
      _counts[id] = (_counts[id] ?? 0) + 1;
    });
  }

  void _decrement(PlateTierId id) {
    if ((_counts[id] ?? 0) <= 0) return;
    HapticFeedback.selectionClick();
    setState(() {
      _counts[id] = (_counts[id] ?? 0) - 1;
    });
  }

  void _resetAll() {
    setState(() {
      for (final tier in SushiPlateTier.all) {
        _counts[tier.id] = 0;
      }
    });
  }

  Future<void> _openScanner() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ScannerScreen(
          onPlateScanned: (SushiPlateTier tier) {
            _increment(tier.id);
          },
          getBill: () => SushiBillSummary(counts: _counts),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bill = SushiBillSummary(counts: _counts);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'KaitenBill คิดเงินซูชิ',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        actions: [
          TextButton(
            onPressed: bill.totalPlates > 0 ? _resetAll : null,
            child: const Text('ล้างรายการ'),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              itemCount: SushiPlateTier.all.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final tier = SushiPlateTier.all[index];
                final qty = _counts[tier.id] ?? 0;

                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFE7E4DC)),
                  ),
                  child: Row(
                    children: [
                      // สัญลักษณ์สีจานซูชิ
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: tier.plateColor,
                          border: Border.all(color: tier.borderColor, width: 3),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          '฿\${tier.priceThb}',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: tier.textColor,
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\${tier.nameTh} · \${tier.priceThb} บาท',
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              tier.examplesTh,
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF6B6761),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          IconButton(
                            onPressed: qty > 0 ? () => _decrement(tier.id) : null,
                            icon: const Icon(Icons.remove_circle_outline),
                          ),
                          SizedBox(
                            width: 28,
                            child: Text(
                              '\$qty',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () => _increment(tier.id),
                            icon: const Icon(
                              Icons.add_circle,
                              color: Color(0xFFC83E2B),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          // สรุปราคาก่อนและหลังคิดค่าบริการ 10%
          Container(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: Color(0xFFE7E4DC))),
            ),
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _SummaryRow(
                    label: 'ราคาก่อนคิดค่าบริการ (\${bill.totalPlates} จาน)',
                    value: '฿\${_thbFormat.format(bill.subtotal)}',
                  ),
                  const SizedBox(height: 6),
                  _SummaryRow(
                    label: 'ค่าบริการ 10% (Service Charge)',
                    value: '+฿\${_thbFormat.format(bill.serviceCharge)}',
                    muted: true,
                  ),
                  const Divider(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'ยอดสุทธิหลังค่าบริการ 10%',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '฿\${_thbFormat.format(bill.grandTotal)}',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFFC83E2B),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: FilledButton.icon(
                      onPressed: _openScanner,
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFC83E2B),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      icon: const Icon(Icons.qr_code_scanner),
                      label: const Text(
                        'สแกนบาร์โค้ด / คิวอาร์โค้ดจานซูชิ',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;
  final bool muted;

  const _SummaryRow({
    required this.label,
    required this.value,
    this.muted = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = muted ? const Color(0xFF6B6761) : const Color(0xFF1A1918);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontSize: 14, color: color)),
        Text(
          value,
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      ],
    );
  }
}
`,
  },
  {
    path: 'lib/screens/scanner_screen.dart',
    label: 'scanner_screen.dart',
    language: 'dart',
    summaryTh: 'หน้ากล้องสแกนบาร์โค้ดและ QR Code อัตโนมัติด้วย mobile_scanner พร้อมระบบป้องกันสแกนซ้ำ',
    content: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../models/sushi_plate.dart';

class ScannerScreen extends StatefulWidget {
  final void Function(SushiPlateTier tier) onPlateScanned;
  final SushiBillSummary Function() getBill;

  const ScannerScreen({
    super.key,
    required this.onPlateScanned,
    required this.getBill,
  });

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.normal,
    facing: CameraFacing.back,
  );
  final NumberFormat _thbFormat = NumberFormat('#,##0.00', 'th_TH');

  DateTime? _lastScanTime;
  String? _lastScannedMessage;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleBarcode(BarcodeCapture capture) {
    final now = DateTime.now();
    if (_lastScanTime != null &&
        now.difference(_lastScanTime!).inMilliseconds < 1200) {
      return; // ป้องกันการสแกนจานเดิมซ้ำติดกัน
    }

    for (final barcode in capture.barcodes) {
      final raw = barcode.rawValue;
      if (raw == null) continue;

      final tier = SushiPlateTier.matchBarcode(raw);
      if (tier != null) {
        _lastScanTime = now;
        HapticFeedback.mediumImpact();
        widget.onPlateScanned(tier);
        setState(() {
          _lastScannedMessage = 'เพิ่ม \${tier.nameTh} (฿\${tier.priceThb}) แล้ว';
        });
        break;
      } else {
        _lastScanTime = now;
        setState(() {
          _lastScannedMessage = 'ไม่พบรหัสจานซูชิ: \$raw';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final bill = widget.getBill();

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('สแกนบาร์โค้ด / QR จานซูชิ'),
        actions: [
          IconButton(
            onPressed: () => _controller.toggleTorch(),
            icon: const Icon(Icons.flash_on),
          ),
        ],
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _handleBarcode,
          ),

          // กรอบเล็งสแกนบาร์โค้ด
          Center(
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFC83E2B), width: 3),
                borderRadius: BorderRadius.circular(24),
              ),
            ),
          ),

          // แสดงสถานะและยอดสะสมล่าสุดแบบเรียลไทม์
          Positioned(
            left: 16,
            right: 16,
            bottom: 24,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.96),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_lastScannedMessage != null) ...[
                    Text(
                      _lastScannedMessage!,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Color(0xFFC83E2B),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('ก่อนค่าบริการ (\${bill.totalPlates} จาน)'),
                      Text(
                        '฿\${_thbFormat.format(bill.subtotal)}',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'รวมค่าบริการ 10%',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        '฿\${_thbFormat.format(bill.grandTotal)}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFFC83E2B),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
`,
  },
];
