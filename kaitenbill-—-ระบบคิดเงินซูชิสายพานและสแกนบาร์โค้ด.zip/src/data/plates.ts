export type PlateId = 'white' | 'red' | 'silver' | 'gold' | 'black';

export interface SushiPlateTier {
  id: PlateId;
  tierNumber: number;
  nameTh: string;
  nameEn: string;
  price: number;
  tierLabelTh: string;
  examplesTh: string;
  menuItems: string[];
  qrCode: string;
  ean13: string;
  aliases: string[];
  imageUrl: string;
  /** Visual colors for ceramic plate SVG & rim accents */
  plateFill: string;
  plateRim: string;
  plateInnerRing: string;
  plateTextOnSwatch: string;
}

export const SUSHI_PLATES: SushiPlateTier[] = [
  {
    id: 'white',
    tierNumber: 1,
    nameTh: 'จานสีขาว',
    nameEn: 'White Plate',
    price: 30,
    tierLabelTh: 'เมนูเริ่มต้น',
    examplesTh: 'ยำสาหร่าย · ไข่กุ้ง · ข้าวปั้นสาหร่าย · ซุปมิโซะ',
    menuItems: ['ยำสาหร่ายวากาเมะ', 'กุงกังไข่กุ้ง', 'อินาริเต้าหู้หวาน', 'ซุปมิโซะ'],
    qrCode: 'SUSHI-W30',
    ean13: '8850100000309',
    aliases: ['WHITE', 'W30', '30', 'ขาว', 'จานสีขาว', 'SUSHI-W30', '8850100000309'],
    imageUrl: '/src/assets/images/sushi_white_plate_1795328356022.jpg',
    plateFill: '#FFFFFF',
    plateRim: '#CBD5E1',
    plateInnerRing: '#E2E8F0',
    plateTextOnSwatch: '#1E293B',
  },
  {
    id: 'red',
    tierNumber: 2,
    nameTh: 'จานสีแดง',
    nameEn: 'Red Plate',
    price: 40,
    tierLabelTh: 'เมนูทั่วไป',
    examplesTh: 'แซลมอน · ไข่หวาน · ปูอัด · ทูน่าสลัด',
    menuItems: ['แซลมอนนิกิริ', 'ไข่หวานทามาโกะ', 'ปูอัดคานิคามะ', 'กุงกังทูน่าสลัด'],
    qrCode: 'SUSHI-R40',
    ean13: '8850100000408',
    aliases: ['RED', 'R40', '40', 'แดง', 'จานสีแดง', 'SUSHI-R40', '8850100000408'],
    imageUrl: '/src/assets/images/sushi_red_plate_1795328355840.jpg',
    plateFill: '#C83E2B',
    plateRim: '#992A1B',
    plateInnerRing: '#E0604E',
    plateTextOnSwatch: '#FFFFFF',
  },
  {
    id: 'silver',
    tierNumber: 3,
    nameTh: 'จานสีเงิน',
    nameEn: 'Silver Plate',
    price: 60,
    tierLabelTh: 'เมนูพิเศษ',
    examplesTh: 'มากุโระ · หมึกโฮตารุ · แซลมอนเบิร์น · อิคุระ',
    menuItems: ['มากุโระอากามิ', 'หมึกโฮตารุอิกะ', 'แซลมอนเบิร์นชีส', 'กุ้งหวานอามะเอบิ'],
    qrCode: 'SUSHI-S60',
    ean13: '8850100000606',
    aliases: ['SILVER', 'S60', '60', 'เงิน', 'จานสีเงิน', 'SUSHI-S60', '8850100000606'],
    imageUrl: '/src/assets/images/sushi_silver_plate_1795328355529.jpg',
    plateFill: '#B6BDC6',
    plateRim: '#6B7280',
    plateInnerRing: '#DCE1E7',
    plateTextOnSwatch: '#111827',
  },
  {
    id: 'gold',
    tierNumber: 4,
    nameTh: 'จานสีทอง/สีเหลือง',
    nameEn: 'Gold Plate',
    price: 80,
    tierLabelTh: 'เมนูพรีเมียม · ปรุงพิเศษ',
    examplesTh: 'ปลาไหลอุนางิ · เอ็นกาวะเบิร์น · แซลมอนทรัฟเฟิล',
    menuItems: ['ปลาไหลย่างอุนางิ', 'เอ็นกาวะเบิร์นซอสพอนสึ', 'แซลมอนซอสทรัฟเฟิล', 'ฮามาจิท็อปยูซุ'],
    qrCode: 'SUSHI-G80',
    ean13: '8850100000804',
    aliases: ['GOLD', 'YELLOW', 'G80', '80', 'ทอง', 'เหลือง', 'จานสีทอง', 'จานสีเหลือง', 'SUSHI-G80', '8850100000804'],
    imageUrl: '/src/assets/images/sushi_gold_plate_1795328356166.jpg',
    plateFill: '#D4A742',
    plateRim: '#9C751D',
    plateInnerRing: '#EBD085',
    plateTextOnSwatch: '#1F1A0F',
  },
  {
    id: 'black',
    tierNumber: 5,
    nameTh: 'จานสีดำ',
    nameEn: 'Black Plate',
    price: 120,
    tierLabelTh: 'เมนูพรีเมียมสูงสุด',
    examplesTh: 'โฮตาเตะฮอกไกโด · เนื้อวากิว A5 · โอโทโร่ · อูนิ',
    menuItems: ['โฮตาเตะฮอกไกโด', 'เนื้อวากิว A5 เบิร์นไฟ', 'โอโทโร่ครีบน้ำเงิน', 'ไข่หอยเม่นอูนิ'],
    qrCode: 'SUSHI-B120',
    ean13: '8850100001207',
    aliases: ['BLACK', 'B120', '120', 'ดำ', 'จานสีดำ', 'SUSHI-B120', '8850100001207'],
    imageUrl: '/src/assets/images/sushi_black_plate_1795328356167.jpg',
    plateFill: '#1D1D1F',
    plateRim: '#09090B',
    plateInnerRing: '#444449',
    plateTextOnSwatch: '#FFFFFF',
  },
];

export const INITIAL_COUNTS: Record<PlateId, number> = {
  white: 0,
  red: 0,
  silver: 0,
  gold: 0,
  black: 0,
};

export interface ScanLogItem {
  id: string;
  plateId: PlateId;
  source: 'camera' | 'manual-code' | 'tap' | 'image-file';
  rawCode: string;
  timestamp: number;
}

export interface SavedBill {
  id: string;
  tableNumber: string;
  createdAt: number;
  counts: Record<PlateId, number>;
  totalPlates: number;
  subtotal: number;
  serviceCharge: number;
  totalAfterService: number;
  vatAmount: number;
  grandTotal: number;
  includeVat: boolean;
  diners: number;
}

export interface BillCalculation {
  totalPlates: number;
  subtotal: number;
  serviceChargeRate: number;
  serviceCharge: number;
  totalAfterService: number;
  vatRate: number;
  vatAmount: number;
  grandTotal: number;
}

export function calculateBill(
  counts: Record<PlateId, number>,
  includeVat = false,
  serviceChargeRate = 0.1
): BillCalculation {
  let totalPlates = 0;
  let subtotal = 0;

  for (const plate of SUSHI_PLATES) {
    const qty = Math.max(0, counts[plate.id] || 0);
    totalPlates += qty;
    subtotal += qty * plate.price;
  }

  const serviceCharge = +(subtotal * serviceChargeRate).toFixed(2);
  const totalAfterService = +(subtotal + serviceCharge).toFixed(2);
  const vatRate = includeVat ? 0.07 : 0;
  const vatAmount = includeVat ? +(totalAfterService * 0.07).toFixed(2) : 0;
  const grandTotal = +(totalAfterService + vatAmount).toFixed(2);

  return {
    totalPlates,
    subtotal,
    serviceChargeRate,
    serviceCharge,
    totalAfterService,
    vatRate,
    vatAmount,
    grandTotal,
  };
}

/**
 * Matches any QR payload, EAN-13 barcode, JSON string, or Thai/English plate name/price
 * to one of the 5 Kaiten sushi plate tiers.
 */
export function parsePlateBarcode(rawInput: string): SushiPlateTier | null {
  const cleaned = rawInput.trim();
  if (!cleaned) return null;

  // Attempt JSON payload e.g. {"plate":"red"} or {"code":"SUSHI-B120"} or {"price":120}
  if (cleaned.startsWith('{') && cleaned.endsWith('}')) {
    try {
      const parsed = JSON.parse(cleaned) as Record<string, unknown>;
      const candidates = [parsed.code, parsed.plate, parsed.color, parsed.id, parsed.price]
        .filter((v) => v !== undefined && v !== null)
        .map((v) => String(v));
      for (const candidate of candidates) {
        const hit = parsePlateBarcode(candidate);
        if (hit) return hit;
      }
    } catch {
      // fall through to string matching
    }
  }

  const upper = cleaned.toUpperCase();

  // 1. Exact QR, EAN-13, or alias match
  for (const plate of SUSHI_PLATES) {
    if (
      plate.qrCode.toUpperCase() === upper ||
      plate.ean13 === upper ||
      plate.id.toUpperCase() === upper ||
      plate.aliases.some((alias) => alias.toUpperCase() === upper)
    ) {
      return plate;
    }
  }

  // 2. Substring match for URLs or custom SKU codes containing plate keys (e.g. KAITEN:GOLD:80)
  for (const plate of SUSHI_PLATES) {
    if (
      upper.includes(plate.qrCode.toUpperCase()) ||
      upper.includes(plate.ean13) ||
      upper.includes(plate.id.toUpperCase()) ||
      plate.aliases.some((alias) => alias.length >= 2 && upper.includes(alias.toUpperCase()))
    ) {
      return plate;
    }
  }

  return null;
}

export function formatThb(amount: number, showDecimals = true): string {
  return new Intl.NumberFormat('th-TH', {
    minimumFractionDigits: showDecimals ? 2 : 0,
    maximumFractionDigits: showDecimals ? 2 : 0,
  }).format(amount);
}

let sharedAudioCtx: AudioContext | null = null;

export function playScanBeep(success = true): void {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    if (!sharedAudioCtx) {
      sharedAudioCtx = new AudioCtx();
    }
    if (sharedAudioCtx.state === 'suspended') {
      void sharedAudioCtx.resume();
    }
    const osc = sharedAudioCtx.createOscillator();
    const gain = sharedAudioCtx.createGain();
    osc.type = success ? 'sine' : 'triangle';
    osc.frequency.setValueAtTime(success ? 1180 : 320, sharedAudioCtx.currentTime);
    if (success) {
      osc.frequency.exponentialRampToValueAtTime(1680, sharedAudioCtx.currentTime + 0.08);
    }
    gain.gain.setValueAtTime(0.001, sharedAudioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.14, sharedAudioCtx.currentTime + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, sharedAudioCtx.currentTime + (success ? 0.14 : 0.22));
    osc.connect(gain);
    gain.connect(sharedAudioCtx.destination);
    osc.start();
    osc.stop(sharedAudioCtx.currentTime + (success ? 0.15 : 0.24));
  } catch {
    // Ignore Web Audio errors on restricted devices
  }
}
