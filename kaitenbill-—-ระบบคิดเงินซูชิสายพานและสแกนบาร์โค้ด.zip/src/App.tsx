import React, { useEffect, useMemo, useState } from 'react';
import {
  Calculator,
  Code2,
  History,
  Minus,
  Plus,
  QrCode,
  ReceiptText,
  RotateCcw,
  ScanBarcode,
  Trash2,
  Users,
} from 'lucide-react';
import {
  INITIAL_COUNTS,
  PlateId,
  SUSHI_PLATES,
  SavedBill,
  ScanLogItem,
  SushiPlateTier,
  calculateBill,
  formatThb,
  parsePlateBarcode,
  playScanBeep,
} from './data/plates';
import {
  PlateCeramicSwatch,
  PlatePhotoThumb,
  PlateStackVisual,
} from './components/PlateStackVisual';
import { BarcodeScannerView } from './components/BarcodeScannerView';
import { QrStickersView } from './components/QrStickersView';
import { FlutterCodeView } from './components/FlutterCodeView';
import { BillReceiptModal } from './components/BillReceiptModal';

type ActiveTab = 'calculator' | 'scanner' | 'stickers' | 'flutter';

const HISTORY_STORAGE_KEY = 'kaitenbill_saved_history_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('calculator');
  const [counts, setCounts] = useState<Record<PlateId, number>>({
    white: 1,
    red: 2,
    silver: 1,
    gold: 1,
    black: 1,
  });
  const [scanLog, setScanLog] = useState<ScanLogItem[]>([]);
  const [quickCode, setQuickCode] = useState('');
  const [quickCodeMessage, setQuickCodeMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [tableNumber, setTableNumber] = useState('A-04');
  const [diners, setDiners] = useState(2);
  const [includeVat, setIncludeVat] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [confirmClear, setConfirmClear] = useState(false);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [savedBills, setSavedBills] = useState<SavedBill[]>(() => {
    try {
      const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as SavedBill[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(savedBills));
    } catch {
      // ignore storage quota errors
    }
  }, [savedBills]);

  const bill = useMemo(
    () => calculateBill(counts, includeVat, 0.1),
    [counts, includeVat]
  );

  const addPlate = (
    plate: SushiPlateTier,
    source: 'camera' | 'manual-code' | 'tap' | 'image-file' = 'tap',
    rawCode?: string
  ) => {
    setCounts((prev) => ({
      ...prev,
      [plate.id]: (prev[plate.id] || 0) + 1,
    }));
    setScanLog((prev) => [
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        plateId: plate.id,
        source,
        rawCode: rawCode || plate.qrCode,
        timestamp: Date.now(),
      },
      ...prev.slice(0, 29),
    ]);
    setConfirmClear(false);
    if (soundEnabled) {
      playScanBeep(true);
    }
  };

  const decrementPlate = (plateId: PlateId) => {
    setCounts((prev) => ({
      ...prev,
      [plateId]: Math.max(0, (prev[plateId] || 0) - 1),
    }));
  };

  const undoLastScan = () => {
    setScanLog((prev) => {
      if (prev.length === 0) return prev;
      const [latest, ...rest] = prev;
      setCounts((c) => ({
        ...c,
        [latest.plateId]: Math.max(0, (c[latest.plateId] || 0) - 1),
      }));
      return rest;
    });
  };

  const handleClearBill = () => {
    if (!confirmClear) {
      setConfirmClear(true);
      window.setTimeout(() => setConfirmClear(false), 3500);
      return;
    }
    setCounts({ ...INITIAL_COUNTS });
    setScanLog([]);
    setConfirmClear(false);
  };

  const handleQuickCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const raw = quickCode.trim();
    if (!raw) return;
    const matched = parsePlateBarcode(raw);
    if (matched) {
      addPlate(matched, 'manual-code', raw);
      setQuickCode('');
      setQuickCodeMessage({
        type: 'success',
        text: `สแกนเพิ่ม ${matched.nameTh} (+฿${matched.price}) เรียบร้อย`,
      });
    } else {
      if (soundEnabled) playScanBeep(false);
      setQuickCodeMessage({
        type: 'error',
        text: `ไม่พบรหัส "${raw}" (ลองพิมพ์ SUSHI-R40, black, gold หรือ 120)`,
      });
    }
  };

  const handleSaveCurrentBill = () => {
    if (bill.totalPlates === 0) return;
    const entry: SavedBill = {
      id: `BILL-${Date.now()}`,
      tableNumber: tableNumber.trim() || 'ทั่วไป',
      createdAt: Date.now(),
      counts: { ...counts },
      totalPlates: bill.totalPlates,
      subtotal: bill.subtotal,
      serviceCharge: bill.serviceCharge,
      totalAfterService: bill.totalAfterService,
      vatAmount: bill.vatAmount,
      grandTotal: bill.grandTotal,
      includeVat,
      diners,
    };
    setSavedBills((prev) => [entry, ...prev.slice(0, 19)]);
  };

  const handleDeleteSavedBill = (id: string) => {
    setSavedBills((prev) => prev.filter((item) => item.id !== id));
  };

  const navItems: { id: ActiveTab; label: string; shortLabel: string; icon: React.ReactNode }[] = [
    {
      id: 'calculator',
      label: 'คิดเงินตามจาน',
      shortLabel: 'คิดเงิน',
      icon: <Calculator className="w-5 h-5" />,
    },
    {
      id: 'scanner',
      label: 'สแกนบาร์โค้ด',
      shortLabel: 'สแกน',
      icon: <ScanBarcode className="w-5 h-5" />,
    },
    {
      id: 'stickers',
      label: 'รหัส QR จาน',
      shortLabel: 'ป้าย QR',
      icon: <QrCode className="w-5 h-5" />,
    },
    {
      id: 'flutter',
      label: 'โค้ด Flutter',
      shortLabel: 'Flutter',
      icon: <Code2 className="w-5 h-5" />,
    },
  ];

  const finalPayable = includeVat ? bill.grandTotal : bill.totalAfterService;
  const perPersonAmount = diners > 1 ? finalPayable / diners : finalPayable;

  return (
    <div className="min-h-screen bg-[#F7F6F2] text-[#1A1918] flex flex-col">
      {/* Top Bar — Strict 3-Zone Contract */}
      <header className="sticky top-0 z-30 h-14 md:h-16 bg-white/95 backdrop-blur-md border-b border-[#E6E3DC]">
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('calculator')}
            className="font-display text-lg font-extrabold tracking-tight text-[#1A1918] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C83E2B]"
          >
            KaitenBill
          </button>

          {/* Zone 2: 4 Clean Single-Line Nav Links (Desktop) */}
          <nav
            aria-label="เมนูหลัก"
            className="hidden md:flex items-center gap-7 text-sm font-medium"
          >
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`py-1.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'border-[#C83E2B] text-[#1A1918] font-semibold'
                      : 'border-transparent text-[#6B6761] hover:text-[#1A1918]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('scanner')}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-[#C83E2B] hover:bg-[#B23423] text-white text-xs sm:text-sm font-semibold transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <ScanBarcode className="w-4 h-4" />
              <span>เปิดกล้องสแกน</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8 pb-24 md:pb-12">
        {activeTab === 'calculator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
            {/* Left Column: Plate Pricing & Interactive Stepper List */}
            <section className="lg:col-span-7 space-y-5" aria-label="รายการสีจานซูชิ">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
                <div>
                  <h1 className="text-2xl sm:text-[28px] font-bold tracking-tight text-[#1A1918]">
                    คำนวณยอดซูชิตามสีจาน
                  </h1>
                  <p className="text-sm text-[#6B6761] mt-1">
                    เลือกจำนวนจานแต่ละสีหรือสแกนบาร์โค้ด · คำนวณราคาก่อนและหลังค่าบริการ 10% อัตโนมัติ
                  </p>
                </div>
                {scanLog.length > 0 && (
                  <button
                    type="button"
                    onClick={undoLastScan}
                    className="min-h-[44px] px-3.5 rounded-xl bg-white border border-[#E6E3DC] hover:bg-[#F2F0EB] text-xs font-semibold text-[#1A1918] transition-colors inline-flex items-center gap-1.5 self-start sm:self-auto whitespace-nowrap shrink-0"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>ย้อนจานล่าสุด</span>
                  </button>
                )}
              </div>

              {/* Quick Barcode / SKU Input Bar */}
              <form
                onSubmit={handleQuickCodeSubmit}
                className="bg-white rounded-2xl border border-[#E6E3DC] p-3.5 flex flex-col sm:flex-row gap-2.5"
              >
                <div className="relative flex-1">
                  <ScanBarcode className="w-4 h-4 text-[#6B6761] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={quickCode}
                    onChange={(e) => {
                      setQuickCode(e.target.value);
                      if (quickCodeMessage) setQuickCodeMessage(null);
                    }}
                    placeholder="ยิงบาร์โค้ด หรือพิมพ์รหัสจาน เช่น SUSHI-R40, gold, 120"
                    className="w-full min-h-[44px] pl-10 pr-3 rounded-xl bg-[#F7F6F2] border border-[#E6E3DC] text-sm text-[#1A1918] placeholder:text-[#8E8980] focus:outline-none focus:border-[#C83E2B] focus:bg-white transition-colors font-mono"
                    aria-label="รหัสบาร์โค้ดหรือคิวอาร์โค้ดจานซูชิ"
                  />
                </div>
                <button
                  type="submit"
                  className="min-h-[44px] px-4 rounded-xl bg-[#1A1918] hover:bg-[#312F2D] text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
                >
                  เพิ่มจาน
                </button>
              </form>

              {quickCodeMessage && (
                <p
                  className={`text-xs font-medium px-1 ${
                    quickCodeMessage.type === 'success'
                      ? 'text-[#1E6B35]'
                      : 'text-[#B23423]'
                  }`}
                >
                  {quickCodeMessage.text}
                </p>
              )}

              {/* 5 Plate Tier Cards */}
              <div className="bg-white rounded-2xl border border-[#E6E3DC] divide-y divide-[#ECE9E2] overflow-hidden">
                {SUSHI_PLATES.map((plate) => {
                  const qty = counts[plate.id] || 0;
                  const lineTotal = qty * plate.price;

                  return (
                    <div
                      key={plate.id}
                      className={`p-4 sm:p-5 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                        qty > 0 ? 'bg-[#FCFBF9]' : 'bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                        <PlatePhotoThumb plate={plate} className="w-16 h-16 sm:w-[72px] sm:h-[72px]" />

                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                            <h2 className="text-base font-bold text-[#1A1918]">
                              {plate.tierNumber}. {plate.nameTh}
                            </h2>
                            <span className="text-xs text-[#6B6761]">
                              {plate.tierLabelTh}
                            </span>
                          </div>

                          <p className="text-xs sm:text-[13px] text-[#5C5852] mt-1 leading-relaxed">
                            {plate.examplesTh}
                          </p>

                          <div className="flex items-center gap-2 mt-1.5 text-xs text-[#6B6761] font-mono tabular-nums">
                            <span className="font-semibold text-[#1A1918]">
                              ฿{plate.price} / จาน
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>{plate.qrCode}</span>
                          </div>
                        </div>
                      </div>

                      {/* Tactile Touch Stepper >= 44px */}
                      <div className="flex items-center justify-between sm:justify-end gap-4 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#F1EFEA] shrink-0">
                        <div className="sm:text-right min-w-[74px]">
                          <p className="text-[11px] text-[#6B6761]">รวมรายการ</p>
                          <p
                            className={`font-mono text-sm font-bold tabular-nums ${
                              qty > 0 ? 'text-[#1A1918]' : 'text-[#A8A39A]'
                            }`}
                          >
                            ฿{formatThb(lineTotal, false)}
                          </p>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => decrementPlate(plate.id)}
                            disabled={qty === 0}
                            aria-label={`ลดจำนวน${plate.nameTh}`}
                            className="min-h-[44px] min-w-[44px] rounded-xl border border-[#E2DFD7] bg-white hover:bg-[#F7F6F2] active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all flex items-center justify-center text-[#1A1918]"
                          >
                            <Minus className="w-4 h-4" />
                          </button>

                          <span
                            className="w-9 text-center font-mono text-base font-bold tabular-nums text-[#1A1918]"
                            aria-live="polite"
                          >
                            {qty}
                          </span>

                          <button
                            type="button"
                            onClick={() => addPlate(plate, 'tap')}
                            aria-label={`เพิ่มจำนวน${plate.nameTh}`}
                            className="min-h-[44px] min-w-[44px] rounded-xl bg-[#C83E2B] hover:bg-[#B23423] active:scale-95 transition-all flex items-center justify-center text-white"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Recent Scan Log */}
              {scanLog.length > 0 && (
                <div className="bg-white rounded-2xl border border-[#E6E3DC] p-5">
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <h3 className="text-sm font-bold text-[#1A1918]">
                      ประวัติการสแกนและเพิ่มจานล่าสุด
                    </h3>
                    <span className="text-xs text-[#6B6761] font-mono tabular-nums">
                      {scanLog.length} รายการ
                    </span>
                  </div>
                  <div className="divide-y divide-[#F1EFEA] max-h-56 overflow-y-auto">
                    {scanLog.slice(0, 8).map((entry) => {
                      const plate = SUSHI_PLATES.find((p) => p.id === entry.plateId);
                      if (!plate) return null;
                      const sourceLabel =
                        entry.source === 'camera'
                          ? 'สแกนกล้อง'
                          : entry.source === 'image-file'
                          ? 'สแกนจากภาพ'
                          : entry.source === 'manual-code'
                          ? 'รหัสบาร์โค้ด'
                          : 'กดเพิ่มจาน';
                      return (
                        <div
                          key={entry.id}
                          className="py-2.5 flex items-center justify-between gap-3 text-xs sm:text-sm"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <PlateCeramicSwatch plate={plate} size={30} showPrice={false} />
                            <div className="min-w-0">
                              <p className="font-medium text-[#1A1918] truncate">
                                {plate.nameTh}
                              </p>
                              <p className="text-xs text-[#6B6761] truncate">
                                {sourceLabel} · {entry.rawCode} ·{' '}
                                {new Date(entry.timestamp).toLocaleTimeString('th-TH', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit',
                                })}
                              </p>
                            </div>
                          </div>
                          <span className="font-mono font-semibold tabular-nums text-[#1A1918] shrink-0">
                            +฿{plate.price}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Saved Bill History */}
              {savedBills.length > 0 && (
                <div className="bg-white rounded-2xl border border-[#E6E3DC] p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <History className="w-4 h-4 text-[#6B6761]" />
                    <h3 className="text-sm font-bold text-[#1A1918]">
                      ประวัติบิลที่บันทึกไว้ ({savedBills.length})
                    </h3>
                  </div>
                  <div className="divide-y divide-[#F1EFEA]">
                    {savedBills.slice(0, 6).map((item) => (
                      <div
                        key={item.id}
                        className="py-3 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#1A1918]">
                            โต๊ะ {item.tableNumber} · {item.totalPlates} จาน
                          </p>
                          <p className="text-xs text-[#6B6761] mt-0.5 font-mono tabular-nums">
                            ก่อนค่าบริการ ฿{formatThb(item.subtotal)} · หลังค่าบริการ 10% ฿
                            {formatThb(item.totalAfterService)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="font-mono text-sm font-bold tabular-nums text-[#C83E2B]">
                            ฿{formatThb(item.includeVat ? item.grandTotal : item.totalAfterService)}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleDeleteSavedBill(item.id)}
                            aria-label="ลบบิลออกจากประวัติ"
                            className="min-h-[40px] min-w-[40px] rounded-lg hover:bg-[#FDF2F0] text-[#6B6761] hover:text-[#C83E2B] flex items-center justify-center transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </section>

            {/* Right Column: Live Japanese Receipt & 10% Service Charge Calculator */}
            <aside className="lg:col-span-5 lg:sticky lg:top-24" aria-label="สรุปบิลและค่าบริการ 10%">
              <div className="bg-white rounded-2xl border border-[#E6E3DC] p-5 sm:p-6 space-y-5">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-bold text-[#1A1918]">สรุปยอดอาหาร</h2>
                    <p className="text-xs text-[#6B6761]">
                      แสดงราคาก่อนและหลังคิดค่าบริการ 10%
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <label htmlFor="table-no-input" className="text-xs text-[#6B6761]">
                      โต๊ะ
                    </label>
                    <input
                      id="table-no-input"
                      type="text"
                      value={tableNumber}
                      onChange={(e) => setTableNumber(e.target.value)}
                      maxLength={8}
                      className="w-16 min-h-[38px] px-2.5 rounded-lg bg-[#F7F6F2] border border-[#E2DFD7] text-xs font-mono font-semibold text-center text-[#1A1918] focus:outline-none focus:border-[#C83E2B]"
                    />
                  </div>
                </div>

                {/* Visual Plate Stack */}
                <PlateStackVisual counts={counts} totalPlates={bill.totalPlates} />

                {/* Itemized Breakdown */}
                <div className="space-y-2 text-sm">
                  {SUSHI_PLATES.map((plate) => {
                    const qty = counts[plate.id] || 0;
                    if (qty === 0) return null;
                    return (
                      <div
                        key={plate.id}
                        className="flex items-center justify-between gap-2 text-[#1A1918]"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            style={{
                              backgroundColor: plate.plateFill,
                              borderColor: plate.plateRim,
                            }}
                            className="w-3 h-3 rounded-full border shrink-0"
                            aria-hidden="true"
                          />
                          <span className="truncate">{plate.nameTh}</span>
                          <span className="text-xs font-mono tabular-nums text-[#6B6761] shrink-0">
                            ×{qty}
                          </span>
                        </div>
                        <span className="font-mono font-semibold tabular-nums shrink-0">
                          ฿{formatThb(qty * plate.price)}
                        </span>
                      </div>
                    );
                  })}
                </div>

                <div className="h-px receipt-divider" />

                {/* Core Pricing Summary: Before & After 10% Service Charge */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-medium text-[#1A1918]">
                        ราคาก่อนคิดค่าบริการ
                      </p>
                      <p className="text-xs text-[#6B6761]">
                        Subtotal · รวม {bill.totalPlates} จาน
                      </p>
                    </div>
                    <p className="font-mono text-lg font-bold tabular-nums text-[#1A1918]">
                      ฿{formatThb(bill.subtotal)}
                    </p>
                  </div>

                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm text-[#4D4A45]">ค่าบริการ 10%</p>
                      <p className="text-xs text-[#6B6761]">Service Charge 10%</p>
                    </div>
                    <p className="font-mono text-base font-semibold tabular-nums text-[#4D4A45]">
                      +฿{formatThb(bill.serviceCharge)}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#ECE9E2] flex items-baseline justify-between gap-3">
                    <div>
                      <p className="text-base font-bold text-[#1A1918]">
                        ราคาหลังคิดค่าบริการ 10%
                      </p>
                      <p className="text-xs text-[#6B6761]">
                        Net Total (incl. 10% Service)
                      </p>
                    </div>
                    <p className="font-mono text-3xl font-extrabold tabular-nums text-[#C83E2B]">
                      ฿{formatThb(bill.totalAfterService)}
                    </p>
                  </div>

                  {/* Optional VAT 7% Switch */}
                  <div className="pt-2 flex items-center justify-between gap-3 text-xs text-[#6B6761]">
                    <label
                      htmlFor="vat-toggle"
                      className="flex items-center gap-2 cursor-pointer select-none min-h-[36px]"
                    >
                      <input
                        id="vat-toggle"
                        type="checkbox"
                        checked={includeVat}
                        onChange={(e) => setIncludeVat(e.target.checked)}
                        className="w-4 h-4 accent-[#C83E2B] rounded"
                      />
                      <span>คำนวณภาษีมูลค่าเพิ่ม VAT 7% เพิ่มเติม</span>
                    </label>
                    {includeVat && (
                      <span className="font-mono font-semibold tabular-nums text-[#1A1918]">
                        +฿{formatThb(bill.vatAmount)}
                      </span>
                    )}
                  </div>

                  {includeVat && (
                    <div className="p-3 rounded-xl bg-[#FAF9F6] border border-[#EAE7E0] flex items-baseline justify-between">
                      <span className="text-sm font-bold text-[#1A1918]">
                        ยอดสุทธิรวม Service 10% + VAT 7%
                      </span>
                      <span className="font-mono text-xl font-bold tabular-nums text-[#1A1918]">
                        ฿{formatThb(bill.grandTotal)}
                      </span>
                    </div>
                  )}
                </div>

                {/* Split Bill Control */}
                <div className="p-3.5 rounded-xl bg-[#F7F6F2] border border-[#EAE7E0] flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 min-w-0">
                    <Users className="w-4 h-4 text-[#6B6761] shrink-0" />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-[#1A1918]">
                        หารบิล ({diners} ท่าน)
                      </p>
                      <p className="text-xs font-mono tabular-nums text-[#6B6761]">
                        คนละ ฿{formatThb(perPersonAmount)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setDiners((d) => Math.max(1, d - 1))}
                      disabled={diners <= 1}
                      aria-label="ลดจำนวนคนหาร"
                      className="min-h-[40px] min-w-[40px] rounded-lg bg-white border border-[#E2DFD7] hover:bg-[#EFECE5] disabled:opacity-40 flex items-center justify-center"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-7 text-center font-mono text-sm font-bold tabular-nums">
                      {diners}
                    </span>
                    <button
                      type="button"
                      onClick={() => setDiners((d) => Math.min(12, d + 1))}
                      disabled={diners >= 12}
                      aria-label="เพิ่มจำนวนคนหาร"
                      className="min-h-[40px] min-w-[40px] rounded-lg bg-white border border-[#E2DFD7] hover:bg-[#EFECE5] disabled:opacity-40 flex items-center justify-center"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Primary Receipt & Clear Actions */}
                <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
                  <button
                    type="button"
                    disabled={bill.totalPlates === 0}
                    onClick={() => setReceiptOpen(true)}
                    className="flex-1 min-h-[48px] px-4 rounded-xl bg-[#C83E2B] hover:bg-[#B23423] disabled:opacity-40 disabled:pointer-events-none text-white text-sm font-semibold transition-colors flex items-center justify-center gap-2 whitespace-nowrap"
                  >
                    <ReceiptText className="w-4 h-4" />
                    <span>สรุปใบเสร็จ / เช็คบิล</span>
                  </button>
                  <button
                    type="button"
                    disabled={bill.totalPlates === 0}
                    onClick={handleClearBill}
                    className={`min-h-[48px] px-4 rounded-xl border text-sm font-semibold transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 disabled:pointer-events-none ${
                      confirmClear
                        ? 'bg-[#1A1918] border-[#1A1918] text-white'
                        : 'bg-white border-[#E2DFD7] hover:bg-[#F7F6F2] text-[#1A1918]'
                    }`}
                  >
                    {confirmClear ? 'แตะอีกครั้งเพื่อล้าง' : 'ล้างรายการ'}
                  </button>
                </div>
              </div>
            </aside>
          </div>
        )}

        {activeTab === 'scanner' && (
          <BarcodeScannerView
            counts={counts}
            bill={bill}
            soundEnabled={soundEnabled}
            onToggleSound={() => setSoundEnabled((prev) => !prev)}
            onScanPlate={(plate, source, rawCode) => addPlate(plate, source, rawCode)}
            onUndoLastScan={undoLastScan}
            canUndo={scanLog.length > 0}
            onGoToBill={() => setActiveTab('calculator')}
          />
        )}

        {activeTab === 'stickers' && (
          <QrStickersView
            onQuickAddPlate={(plate) => {
              addPlate(plate, 'tap', plate.qrCode);
            }}
          />
        )}

        {activeTab === 'flutter' && <FlutterCodeView />}
      </main>

      {/* Mobile Fixed Bottom Tab Bar (Thumb Zone) */}
      <nav
        aria-label="แถบนำทางด้านล่าง"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E6E3DC] pb-safe"
      >
        <div className="grid grid-cols-4 h-16">
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors ${
                  active ? 'text-[#C83E2B]' : 'text-[#6B6761]'
                }`}
              >
                {item.icon}
                <span className="text-[11px] font-medium tracking-tight whitespace-nowrap">
                  {item.shortLabel}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Receipt Modal */}
      <BillReceiptModal
        open={receiptOpen}
        onClose={() => setReceiptOpen(false)}
        tableNumber={tableNumber}
        counts={counts}
        bill={bill}
        includeVat={includeVat}
        diners={diners}
        onSaveBill={handleSaveCurrentBill}
      />
    </div>
  );
}
